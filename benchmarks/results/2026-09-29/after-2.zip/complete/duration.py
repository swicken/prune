import re


_CHUNK = re.compile(r"(\d+)([hms])")
_SECONDS = {"h": 3600, "m": 60, "s": 1}


def seconds(text):
    if not text:
        raise ValueError("empty duration")

    total = 0
    pos = 0
    for match in _CHUNK.finditer(text):
        if match.start() != pos:
            raise ValueError("invalid duration")
        value, unit = match.groups()
        total += int(value) * _SECONDS[unit]
        pos = match.end()

    if pos != len(text):
        raise ValueError("invalid duration")
    return total
