from duration import seconds


assert seconds("1h30m") == 5400
assert seconds("2m5s") == 125
assert seconds("0s") == 0

for text in ("", "1hX", "-1s", "10"):
    try:
        seconds(text)
    except ValueError:
        pass
    else:
        raise AssertionError(f"{text!r} should raise ValueError")
