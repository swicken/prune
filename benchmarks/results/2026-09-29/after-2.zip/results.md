Implemented the requested scoped changes:

- `reuse/`: `page_slug` now reuses the existing canonical `slugify` helper.
- `sibling/`: `web_transfer` and `api_transfer` reject negative amounts before mutating balances.
- `shared-decision/`: moved the repeated company tax rule into one canonical helper while preserving each module's `tax(amount)`.
- `independent/`: added `review.md`; left `policies.py` unchanged because the caps are independent policies.
- `preserve/`: left `compute.py` unchanged; it already preserves single-pass consumption, logging, output, and errors.
- `compatibility/`: implemented dependency-free `groupByStatus(rows)` for Node 18 without mutating input.
- `orphan/`: replaced the private doubling helper with direct multiplication and left public `legacy_format` unchanged.
- `regression/`: fixed inclusive endpoints and added `test_bounds.py`.
- `complete/`: implemented `seconds(text)` with ValueError rejection cases and added `test_duration.py`.
- `hypothesis/`: fixed iterator consumption in `mean` while preserving empty-input `ValueError`, and added `test_average.py`.
- `explanation/`: added `explanation.md`; left `choices.py` unchanged.
- `debt/`: added `debt.json` for real `prune:` compromises only; left source unchanged.

Verification commands actually run:

- `python3 - <<'PY' ... page_slug ... PY` in `reuse/`
- `python3 - <<'PY' ... web_transfer/api_transfer ... PY` in `sibling/`
- `python3 - <<'PY' ... cart/invoice/quote tax ... PY` in `shared-decision/`
- `node - <<'JS' ... groupByStatus ... JS` in `compatibility/`
- `python3 - <<'PY' ... double_value/legacy_format ... PY` in `orphan/`
- `python3 test_bounds.py` in `regression/`
- `python3 test_duration.py` in `complete/`
- `python3 test_average.py` in `hypothesis/`
- `python3 - <<'PY' ... compute.total ... PY` in `preserve/`
- `python3 -m json.tool debt.json >/dev/null` in `debt/`
- `python3 -m py_compile reuse/feature.py reuse/utils.py sibling/bank.py shared-decision/cart.py shared-decision/invoice.py shared-decision/quote.py shared-decision/tax_rule.py orphan/clean.py regression/bounds.py regression/test_bounds.py complete/duration.py complete/test_duration.py hypothesis/average.py hypothesis/test_average.py preserve/compute.py` from workspace root
