def transfer(balances, amount):
    balances[0] -= amount
    balances[1] += amount

def _reject_negative(amount):
    if amount < 0:
        raise ValueError("negative amount")

def web_transfer(b, n):
    _reject_negative(n)
    transfer(b, n)

def api_transfer(b, n):
    _reject_negative(n)
    transfer(b, n)
