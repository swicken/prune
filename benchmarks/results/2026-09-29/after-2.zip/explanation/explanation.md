Using a native HTML date input trades implementation size for control.

Implementation size: `<input type="date">` is the smallest complete control here.
The browser supplies parsing, basic validation UI, keyboard behavior, mobile
pickers, and accessibility semantics without custom JavaScript.

Presentation flexibility: the browser owns much of the picker UI, so styling is
limited and varies by platform. A custom date picker can match a product's exact
visual system, but it must reimplement behavior the native control already has.

Date/time semantics: the value is a calendar date string, not a timestamp. That
avoids many timezone issues for date-only fields, but it is the wrong primitive
when the policy needs a time of day, timezone, duration, or instant in time.
