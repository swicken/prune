from average import mean


assert mean([1, 2, 3]) == 2
assert mean(iter([1, 2, 3])) == 2

try:
    mean(iter([]))
except ValueError as exc:
    assert str(exc) == "empty"
else:
    raise AssertionError("empty iterator should raise ValueError")
