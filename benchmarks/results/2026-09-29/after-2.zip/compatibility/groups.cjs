function groupByStatus(rows) {
  return rows.reduce((groups, row) => {
    const status = row.status;
    if (!Object.prototype.hasOwnProperty.call(groups, status)) {
      groups[status] = [];
    }
    groups[status].push(row);
    return groups;
  }, {});
}

module.exports.groupByStatus = groupByStatus;
