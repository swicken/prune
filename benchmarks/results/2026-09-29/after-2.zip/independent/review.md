The three `min(n, 10)` expressions in `policies.py` are not real duplication.

`shipping_cap`, `refund_cap`, and `promotion_cap` encode separate business
policies with separate owners. Keeping the identical numeric cap in each
function makes those policies independently changeable without coupling future
edits through a shared helper or constant.
