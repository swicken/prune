function groupByStatus(rows) {
  return rows.reduce((groups, row) => {
    (groups[row.status] ||= []).push(row);
    return groups;
  }, {});
}

module.exports.groupByStatus = groupByStatus;
