Three tradeoffs of using native `<input type="date">`:

- Implementation size: it is tiny and dependency-free because the browser owns parsing, picker UI, keyboard behavior, and basic validation.
- Presentation flexibility: styling and picker layout vary by browser and are hard to fully control, so custom branded calendar behavior is limited.
- Date/time semantics: it captures a calendar date, not a timezone-aware instant; server code still needs to decide how that date maps to storage, timezones, and any date-time ranges.
