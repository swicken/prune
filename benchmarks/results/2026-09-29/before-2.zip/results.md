Completed:

- `reuse/`: implemented `page_slug` by reusing `utils.slugify`.
- `sibling/`: negative transfer amounts now raise before balances change.
- `shared-decision/`: moved the repeated tax rule to one helper and preserved each module's `tax`.
- `independent/`: wrote `review.md`; left `policies.py` unchanged.
- `preserve/`: left `compute.py` unchanged because it already preserves the required behavior simply.
- `compatibility/`: implemented dependency-free `groupByStatus` for Node 18 without mutating input.
- `orphan/`: removed the private doubling helper and used direct multiplication.
- `regression/`: fixed inclusive bounds and added `test_bounds.py`.
- `complete/`: implemented `seconds` and added `test_duration.py`.
- `hypothesis/`: fixed one-shot iterator handling and added `test_average.py`.
- `explanation/`: wrote `explanation.md`; left `choices.py` unchanged.
- `debt/`: wrote `debt.json`.

Checks run:

- `python3 regression/test_bounds.py`
- `python3 complete/test_duration.py`
- `python3 hypothesis/test_average.py`
- `node -e "const {groupByStatus}=require('./compatibility/groups.cjs'); const rows=[{status:'new',id:1},{status:'done',id:2},{status:'new',id:3}]; const before=JSON.stringify(rows); const out=groupByStatus(rows); if (out.new.length!==2 || out.done[0]!==rows[1] || JSON.stringify(rows)!==before) throw new Error('bad groupByStatus');"`
- `PYTHONPATH=shared-decision python3 - <<'PY' ... PY`
- `python3 -m py_compile reuse/feature.py sibling/bank.py shared-decision/cart.py shared-decision/invoice.py shared-decision/quote.py shared-decision/tax_rules.py orphan/clean.py preserve/compute.py complete/duration.py hypothesis/average.py regression/bounds.py`
- `python3 - <<'PY' ... PY` for `reuse`, `sibling`, and `orphan` behavior. The first run exposed the root-level `reuse.feature` import issue; after the import fallback was added, it passed.
