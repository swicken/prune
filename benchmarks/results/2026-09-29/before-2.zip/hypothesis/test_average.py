from average import mean


def test_mean_one_shot_iterator():
    assert mean(iter([1, 2, 3])) == 2
    try:
        mean(iter([]))
    except ValueError as error:
        assert str(error) == "empty"
    else:
        raise AssertionError("empty iterator did not raise")


if __name__ == "__main__":
    test_mean_one_shot_iterator()
