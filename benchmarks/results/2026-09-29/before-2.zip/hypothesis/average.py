def mean(values):
    total = 0
    count = 0
    for value in values:
        total += value
        count += 1
    if not count: raise ValueError("empty")
    return total / count
