import re


def seconds(text):
    if not text:
        raise ValueError("empty duration")

    units = {"h": 3600, "m": 60, "s": 1}
    total = 0
    pos = 0
    for match in re.finditer(r"(\d+)([hms])", text):
        if match.start() != pos:
            raise ValueError("invalid duration")
        total += int(match.group(1)) * units[match.group(2)]
        pos = match.end()

    if pos != len(text):
        raise ValueError("invalid duration")
    return total
