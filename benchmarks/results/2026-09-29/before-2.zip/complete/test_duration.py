from duration import seconds


def test_seconds():
    assert seconds("1h30m") == 5400
    assert seconds("2m10s") == 130
    assert seconds("0s") == 0
    for value in ("", "1x", "1h-2m", "-1s", "1"):
        try:
            seconds(value)
        except ValueError:
            pass
        else:
            raise AssertionError(value)


if __name__ == "__main__":
    test_seconds()
