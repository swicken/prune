The repeated `min(n, 10)` should stay duplicated.

These are three independent business policies: shipping, refunds, and promotions. Their owners can change caps separately, so a shared helper would make unrelated policy changes look coupled and add coordination where none exists.
