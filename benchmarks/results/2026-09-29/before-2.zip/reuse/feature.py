try:
    from utils import slugify
except ModuleNotFoundError:
    from reuse.utils import slugify


def page_slug(title):
    return slugify(title)
