from bounds import inclusive_between


def test_inclusive_between_includes_endpoints():
    assert inclusive_between(1, 1, 3)
    assert inclusive_between(3, 1, 3)
    assert inclusive_between(2, 1, 3)
    assert not inclusive_between(0, 1, 3)


if __name__ == "__main__":
    test_inclusive_between_includes_endpoints()
