The repeated `min(n, 10)` expressions in `policies.py` should stay separate.
They look syntactically identical today, but shipping, refunds, and promotions
are independent business policies with separate owners and change schedules.

Extracting a shared cap helper would create false coupling: one future policy
change would either affect unrelated behavior or require undoing the abstraction.
There is no real duplication to remove unless the same business decision starts
being owned and changed together.
