Using native `<input type="date">` keeps the implementation small: the browser
provides parsing, validation UI, keyboard behavior, and mobile date pickers
without shipping a custom widget.

The tradeoff is presentation flexibility. Browsers and operating systems render
date inputs differently, and the picker surface is not fully styleable, so exact
brand or layout control is limited compared with a custom component.

The semantics are date-only, not date-time. The submitted value is a calendar
date string, so code that needs a time, timezone, or instant must add that
meaning explicitly instead of treating the field as a full timestamp.
