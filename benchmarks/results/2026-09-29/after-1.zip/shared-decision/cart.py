from tax_rule import company_tax


def tax(amount):
    return company_tax(amount)
