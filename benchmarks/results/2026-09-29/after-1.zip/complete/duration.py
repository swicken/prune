import re


CHUNK = re.compile(r"(\d+)([hms])")
MULTIPLIERS = {"h": 3600, "m": 60, "s": 1}


def seconds(text):
    if not text:
        raise ValueError("empty duration")

    total = 0
    pos = 0
    for match in CHUNK.finditer(text):
        if match.start() != pos:
            raise ValueError("invalid duration")
        total += int(match.group(1)) * MULTIPLIERS[match.group(2)]
        pos = match.end()

    if pos != len(text):
        raise ValueError("invalid duration")

    return total
