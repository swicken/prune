from duration import seconds


assert seconds("1h30m") == 5400
assert seconds("2m10s") == 130
assert seconds("0s") == 0

for value in ("", "1hX", "-1s", "1"):
    try:
        seconds(value)
    except ValueError:
        pass
    else:
        raise AssertionError(f"{value!r} should be rejected")
