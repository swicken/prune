module.exports.groupByStatus = (rows) => {
  const groups = {};

  for (const row of rows) {
    const status = row.status;
    if (!groups[status]) groups[status] = [];
    groups[status].push(row);
  }

  return groups;
};
