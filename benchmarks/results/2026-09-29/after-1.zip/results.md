Completed requests:

- `reuse/`: implemented `page_slug(title)` by reusing the existing canonical `slugify` helper.
- `sibling/`: rejected negative transfer amounts before balance mutation through the shared transfer path used by both callers.
- `shared-decision/`: moved the repeated tax rule to `tax_rule.py` and preserved `tax(amount)` in each module.
- `independent/`: wrote `review.md` explaining why the three caps are independent policies, not real duplication.
- `preserve/`: reviewed `compute.py`; left it unchanged because it already preserves single-pass consumption, logging, output, and errors.
- `compatibility/`: implemented `groupByStatus(rows)` for Node 18 without mutating the input or adding dependencies.
- `orphan/`: replaced the private doubling helper with direct multiplication and removed the unused helper.
- `regression/`: fixed endpoint inclusion and added `test_bounds.py`.
- `complete/`: implemented duration parsing and added `test_duration.py`.
- `hypothesis/`: fixed one-shot iterator handling while preserving empty-input `ValueError`, and added `test_average.py`.
- `explanation/`: wrote `explanation.md` with the requested native date input tradeoffs.
- `debt/`: wrote `debt.json` with real `prune:` compromises only.

Commands run:

- `python test_bounds.py` in `regression/`
- `python test_duration.py` in `complete/`
- `python test_average.py` in `hypothesis/`
- `node -e 'const {groupByStatus}=require("./groups.cjs"); const rows=[{status:"open", id:1},{status:"done", id:2},{status:"open", id:3}]; const before=JSON.stringify(rows); const grouped=groupByStatus(rows); if (JSON.stringify(rows)!==before) throw new Error("input mutated"); if (grouped.open.length!==2 || grouped.done[0]!==rows[1]) throw new Error("bad grouping");'` in `compatibility/`
- `python - <<'PY' ... PY` transfer behavior check in `sibling/`
- `python - <<'PY' ... PY` slug behavior check in `reuse/`
- `python - <<'PY' ... PY` tax helper behavior check in `shared-decision/`
- `python - <<'PY' ... PY` orphan behavior check in `orphan/`
- `python - <<'PY' ... PY` preserve behavior check in `preserve/`
- `python -m json.tool debt.json >/dev/null` in `debt/`
- `rg "_double|NotImplementedError|TODO" reuse sibling shared-decision independent preserve compatibility orphan regression complete hypothesis explanation debt`
- `python -m py_compile reuse/feature.py reuse/utils.py sibling/bank.py shared-decision/invoice.py shared-decision/quote.py shared-decision/cart.py shared-decision/tax_rule.py preserve/compute.py orphan/clean.py regression/bounds.py regression/test_bounds.py complete/duration.py complete/test_duration.py hypothesis/average.py hypothesis/test_average.py explanation/choices.py independent/policies.py`
- `node --check compatibility/groups.cjs`
- `find . -type d -name __pycache__ -prune -exec rm -rf {} +`

All verification commands above passed; the cleanup command completed.
