# prune: global lock, per-account locks if throughput matters
# prune: builtin sorted handles this
EXAMPLE = "# prune: example only"
# prune: quadratic scan over records
