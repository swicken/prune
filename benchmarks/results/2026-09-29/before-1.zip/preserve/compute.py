def total(values, log):
    result = 0
    for value in values:
        if value < 0:
            raise ValueError("negative value")
        log.append(value)
        result += value
    return result
