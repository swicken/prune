def double_value(n): return n * 2

def legacy_format(n): return f"legacy:{n}"
