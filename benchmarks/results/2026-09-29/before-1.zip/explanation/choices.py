DATE_INPUT = '<input type="date">'
