`<input type="date">` is tiny to implement: the browser owns the picker, validation UI, keyboard behavior, and mobile date controls, so `choices.py` stays one constant instead of a custom widget.

The tradeoff is presentation flexibility. Native date inputs vary by browser and OS, and only parts of the control can be styled reliably. Use one when consistency is less important than avoiding widget code.

The value is date-only, not a time or timezone-aware moment. That is right for birthdays, deadlines, or policy dates, but wrong when the business rule needs a specific instant or local time.
