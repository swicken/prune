def inclusive_between(n, low, high):
    return low <= n <= high
