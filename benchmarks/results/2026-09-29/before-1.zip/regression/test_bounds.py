from bounds import inclusive_between


assert inclusive_between(1, 1, 3)
assert inclusive_between(3, 1, 3)
assert not inclusive_between(0, 1, 3)
