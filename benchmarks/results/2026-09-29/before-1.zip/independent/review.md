The three `min(n, 10)` caps look duplicated, but they represent independent business policies: shipping, refunds, and promotions.

Keep them separate. A shared helper would couple owners who are expected to change these limits independently.
