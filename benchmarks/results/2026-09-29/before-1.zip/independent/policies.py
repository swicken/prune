def shipping_cap(n): return min(n, 10)
def refund_cap(n): return min(n, 10)
def promotion_cap(n): return min(n, 10)
