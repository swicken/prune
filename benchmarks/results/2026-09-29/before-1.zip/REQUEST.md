Complete the following independent requests in the named subdirectories. Work only in this workspace. Use the instructions in AGENTS.md. Do not access any other project. Run appropriate local checks. Save a concise results.md listing what you did and commands actually run.

reuse/: Implement page_slug(title) in feature.py. Match the existing canonical slug behavior; leave utils.py unchanged.

sibling/: A negative transfer amount increases the sender balance. Fix it in bank.py; both web_transfer and api_transfer must reject negative amounts before mutation.

shared-decision/: These three modules repeat the same company tax rule. Remove real duplication with one canonical tax helper while preserving tax(amount) in each module.

independent/: Review policies.py for duplication. The three caps are independent business policies whose owners change them separately. Write review.md; do not modify policies.py.

preserve/: Simplify compute.py if useful. Preserve single-pass consumption, exceptions, output, and logging behavior; do not alter error messages.

compatibility/: Implement groupByStatus(rows) exported from groups.cjs for the stated Node 18 runtime. Avoid a new dependency. Preserve the input.

orphan/: Replace the private doubling helper with direct multiplication in double_value. Remove anything this change makes unused; leave the unrelated public legacy_format function unchanged.

regression/: Fix bounds.py: inclusive_between must include both endpoints. Leave a runnable regression check in test_bounds.py and run it.

complete/: Implement seconds(text) in duration.py: nonnegative integer h/m/s chunks, such as 1h30m -> 5400; reject empty input, unmatched characters, and negative values with ValueError. Leave a runnable check and run it.

hypothesis/: Fix average.py: mean returns 0 for a one-shot iterator even though it works for lists. Trace the cause, preserve empty-input ValueError, leave and run a regression check.

explanation/: Review choices.py and write explanation.md explaining three concrete tradeoffs of using a native HTML date input: implementation size, presentation flexibility, and date/time semantics. Do not change choices.py.

debt/: Inspect the marked compromises in source.py. Write debt.json as a list of objects with line, ceiling, and trigger (null when absent). Include real compromises, exclude strings and ordinary explanatory comments. Change no source code.
