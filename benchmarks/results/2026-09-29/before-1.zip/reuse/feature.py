from utils import slugify


def page_slug(title):
    return slugify(title)
