module.exports.groupByStatus = rows => rows.reduce((groups, row) => {
  (groups[row.status] ||= []).push(row);
  return groups;
}, {});
