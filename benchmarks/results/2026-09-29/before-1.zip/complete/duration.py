import re


def seconds(text):
    if not text:
        raise ValueError("empty duration")

    total = pos = 0
    for match in re.finditer(r"(\d+)([hms])", text):
        if match.start() != pos:
            raise ValueError("invalid duration")
        value = int(match.group(1))
        unit = match.group(2)
        total += value * {"h": 3600, "m": 60, "s": 1}[unit]
        pos = match.end()

    if pos != len(text):
        raise ValueError("invalid duration")
    return total
