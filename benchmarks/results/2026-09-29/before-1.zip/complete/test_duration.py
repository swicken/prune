from duration import seconds


assert seconds("1h30m") == 5400
assert seconds("2m5s") == 125
assert seconds("0s") == 0

for value in ("", "1h-", "-1s", "1x", "1 h"):
    try:
        seconds(value)
    except ValueError:
        pass
    else:
        raise AssertionError(value)
