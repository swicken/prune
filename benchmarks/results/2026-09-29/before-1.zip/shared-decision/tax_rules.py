def company_tax(amount):
    return round(amount * 0.2, 2)
