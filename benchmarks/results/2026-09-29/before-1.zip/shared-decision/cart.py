def tax(amount):
    from tax_rules import company_tax
    return company_tax(amount)
