def mean(values):
    values = list(values)
    count = len(values)
    if not count: raise ValueError("empty")
    return sum(values) / count
