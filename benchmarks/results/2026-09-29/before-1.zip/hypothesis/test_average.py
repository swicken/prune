from average import mean


assert mean(iter([1, 2, 3])) == 2

try:
    mean(iter([]))
except ValueError:
    pass
else:
    raise AssertionError("empty")
