def transfer(balances, amount):
    if amount < 0:
        raise ValueError("negative amount")
    balances[0] -= amount
    balances[1] += amount

def web_transfer(b, n):
    transfer(b, n)

def api_transfer(b, n):
    transfer(b, n)
